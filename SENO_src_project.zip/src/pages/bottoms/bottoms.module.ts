import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BottomsPage } from './bottoms';

@NgModule({
  declarations: [
    BottomsPage,
  ],
  imports: [
    IonicPageModule.forChild(BottomsPage),
  ],
})
export class BottomsPageModule {}
