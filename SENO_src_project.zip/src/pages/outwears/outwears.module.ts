import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OutwearsPage } from './outwears';

@NgModule({
  declarations: [
    OutwearsPage,
  ],
  imports: [
    IonicPageModule.forChild(OutwearsPage),
  ],
})
export class OutwearsPageModule {}
